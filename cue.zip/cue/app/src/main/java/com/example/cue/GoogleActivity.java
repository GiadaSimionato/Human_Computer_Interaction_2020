package com.example.cue;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GoogleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google);
    }
}